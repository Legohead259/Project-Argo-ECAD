This is the PCB for the Adafruit 16-channel PWM/Servo breakout board
Format is EagleCAD schematic and board layout

For more details, check out the product page at

-----> http://www.adafruit.com/products/815

Adafruit invests time and resources providing this open source design, 
please support Adafruit and open-source hardware by purchasing 
products from Adafruit!

Designed by Adafruit Industries.  
Creative Commons Attribution, Share-Alike license, check license.txt for more information
All text above must be included in any redistribution